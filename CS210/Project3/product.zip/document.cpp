#include "document.h"

Document::Document(const std::string& path, int osType)
    : _path(path, 0) {
}
